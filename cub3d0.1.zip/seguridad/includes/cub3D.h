#ifndef CUB3D_H
# define CUB3D_H

# include "../minilibx-linux/mlx.h"
# include <stdio.h>
# include <stdlib.h>
# include <math.h>
# include <stddef.h>
# include <X11/keysym.h>
# include <X11/X.h>
# include <X11/Xlib.h>
# include <sys/time.h>
# include <unistd.h>
# include <errno.h>
# include <fcntl.h>
# include <stdbool.h>
# include <string.h>
# include <sys/types.h>
# include <sys/stat.h>

# ifndef BONUS
#  define BONUS 1
# endif

# define BLACK 0x000000
# define WHITE 0xFFFFFF
# define DARK_GREEN 0x004400
# define GRAY 0xAAAAAA
# define RED 0xFF0000
# define YELLOW 0xFFFF00
# define SKY_BLUE 0x87CEEB
# define GRASS_GREEN 0x32CD32
#define WALL_BROWN 0x8B4513
#define WALL_RED 0xFF0000
#define WALL_YELLOW 0xFFFF00

# define MAP_WIDTH  10  //ancho
# define MAP_HEIGHT 15  //alto
# define MINI_MAP_WIDTH 60
# define MINI_MAP_HEIGHT 60
# define SCREEN_WIDTH 800 // 800
# define SCREEN_HEIGHT 600 //600
# define WIN_WIDTH 800  // 540
# define WIN_HEIGHT 600  //420
# define MOVE_SPEED 0.0125
# define ROTATE_SPEED 0.15//0.015

# define K_W 119
# define K_S 115
# define K_A 97
# define K_D 100
# define K_LEFT 65361
# define K_RIGHT 65363
# define K_ESC 65307

# define FOV 60

char worldMap2[MAP_HEIGHT][MAP_WIDTH + 1] = {
    "1111111111",
    "1S00000001",
    "1011101101",
    "1000100001",
    "1011101101",
    "1000000001",
    "1011101101",
    "1000100001",
    "1011101101",
    "1000000001",
    "1011101101",
    "1000100001",
    "1011101101",
    "1000000001",
    "1111111111"
};
// --- Minimap Config ---
// --- Minimap Config ---
# define MINIMAP_WIDTH 120   // Fixed width of the minimap (MAP_WIDTH * 8)
# define MINIMAP_HEIGHT 120  // Fixed height of the minimap (MAP_HEIGHT * 8)

// --- Minimap Area Config ---
# define MINIMAP_AREA_OFFSET_X 10 // Offset from the left edge of the window
# define MINIMAP_AREA_OFFSET_Y 10 // Offset from the top edge of the window
# define MINIMAP_AREA_WIDTH 140   // Fixed width of the area
# define MINIMAP_AREA_HEIGHT 170  // Fixed height of the area


#define TEX_WIDTH 64
#define TEX_HEIGHT 64
// --- Estructuras de datos ---

// Estructura para la información de William (el jugador)
typedef struct s_william {
    double x;       // Posición X
    double y;       // Posición Y
    double dir_x;    // Vector dirección X
    double dir_y;    // Vector dirección Y
    double plane_x;  // Plano de la cámara X
    double plane_y;  // Plano de la cámara Y
    double  fov;    // Campo de visión (Field of View)
}   t_william;

// Estructura para la información de las texturas
typedef struct s_texture {
    void    *img_ptr;       // Imagen cargada con mlx_xpm_file_to_image
    int     width;          // Ancho en píxeles (devuelto por mlx)
    int     height;         // Alto en píxeles (devuelto por mlx)
    char    *path;          // Ruta al archivo .xpm
    int     *data;          // Buffer de píxeles (obtenido con mlx_get_data_addr)
    int     bits_per_pixel; // Profundidad de color (normalmente 32)
    int     line_length;    // Cantidad de bytes por fila
    int     endian;         // Orden de bytes (0: little endian, 1: big endian)
} t_texture;

typedef struct s_img
{
    void    *img;
    void    *img_ptr;
    char    *addr;
    int     bits_per_pixel;
    int     line_length;
    int     endian;
    int     width;
    int     height;
    int		size_line;

} t_img;

// Estructura principal del juego
typedef struct s_game {
    void    *mlx_ptr;       // Puntero a la instancia de MiniLibX
    void    *win_ptr;       // Puntero a la ventana
    void    *img_ptr;       // Puntero a la imagen a renderizar (general, para la escena principal)
    int     *img_data;      // Datos de la imagen
    char    *addr;
    t_img   *img_ground; // Puntero a la imagen del fondo
    t_william william;     // Información de William (el jugador)
    //t_texture   north_texture;  // Textura Norte
    //t_texture   south_texture;  // Textura Sur
    //t_texture   east_texture;   // Textura Este
    //t_texture   west_texture;   // Textura Oeste
    int         floor_color;    // Color del suelo
    int         ceiling_color;  // Color del techo
    char        **map;         // Puntero al mapa
    void    *minimap_img_ptr; // Puntero a la imagen del minimapa (añadido)
    int     *minimap_img_data;
    int     minimap_bpp;
    int     minimap_line_length;
    int     minimap_endian;
    int     bits_per_pixel; // Bits per pixel
    int     line_length;    // Tamaño de la línea en bytes
    int     endian;         // Endianness de la imagen
    t_texture   *textures; // Array de texturas
    void *hands_img_ptr[2];        // Arreglo para las dos imágenes de las manos
    int *hands_data[2];            // Arreglo para los datos de las manos (pixeles)
    int hands_width;               // Ancho de las imágenes de las manos
    int hands_height;              // Alto de las imágenes de las manos
    int hands_bits_per_pixel;      // Bits por píxel de las imágenes de las manos
    int hands_line_length;        // Longitud de la línea de las imágenes de las manos
    int hands_endian;             // Endian de las imágenes de las manos
    int current_hand_frame;       // Frame actual de la animación (0 o 1)
    int hand_animation_timer;     // Temporizador para cambiar el fotograma
    int hands_x;                  // Posición X de las manos
    int hands_y;                  // Posición Y de las manos
}   t_game;

// --- Funciones ---
int init_game(t_game *game);
int load_textures(t_game *game);
int render(t_game *game);
int update(t_game *game);
int handle_input(int keycode, t_game *game);
int game_loop(t_game *game);
int clean_exit(t_game *game, char *msg);
void draw_minimap(t_game *game);
void my_mlx_pixel_put(t_game *game, int x, int y, int color);
void drawbackground(t_game *game);
int load_hands_images(t_game *game);
void    remove_black_background(t_game *game);

#endif