#include "../includes/cub3D.h"

/*
int init_game(t_game *game) {


  // Inicializar MiniLibX
  game->mlx_ptr = mlx_init();
  if (!game->mlx_ptr) {
    return (clean_exit(game, "Error: Failed to initialize MiniLibX."));
  }
    game->textures = malloc(5 * sizeof(t_texture));
    if (!game->textures) {
        return (clean_exit(game, "Error: Failed to allocate memory for textures."));
    }
  // Crear la ventana principal
  game->win_ptr =
      mlx_new_window(game->mlx_ptr, WIN_WIDTH, WIN_HEIGHT, "cub3D - William");
  if (!game->win_ptr) {
    return (clean_exit(game, "Error: Failed to create window."));
  }

  // Crear la imagen principal (para la vista 3D)
  game->img_ptr = mlx_new_image(game->mlx_ptr, WIN_WIDTH, WIN_HEIGHT);
  game->img_data = (int *)mlx_get_data_addr(
      game->img_ptr, &game->bits_per_pixel, &game->line_length, &game->endian);
  if (!game->img_data) {
    return (clean_exit(game, "Error: Failed to get main image data address."));
  }

  // Crear la imagen del minimapa
  game->minimap_img_ptr =
      mlx_new_image(game->mlx_ptr, MINIMAP_WIDTH, MINIMAP_HEIGHT);
  game->minimap_img_data = (int *)mlx_get_data_addr(
      game->minimap_img_ptr, &game->minimap_bpp, &game->minimap_line_length,
      &game->minimap_endian);
  if (!game->minimap_img_data) {
    return (
        clean_exit(game, "Error: Failed to get minimap image data address."));
  }

  // Asignar memoria para el mapa y copiarlo
  game->map = malloc(MAP_HEIGHT * sizeof(char *));
  if (!game->map)
    return (clean_exit(game, "Error: Failed to allocate memory for map."));
  for (int i = 0; i < MAP_HEIGHT; i++) {
    game->map[i] = malloc((MAP_WIDTH + 1) * sizeof(char));
    if (!game->map[i])
      return (clean_exit(game, "Error: Failed to allocate memory for map row."));
    for (int j = 0; j <= MAP_WIDTH; j++) {
      game->map[i][j] = worldMap2[i][j];
    }
  }

  // Inicializar la posición y dirección de William
  game->william.fov = FOV * M_PI / 180.0; // 60 grados a radianes
  for (int y = 0; y < MAP_HEIGHT; y++) {
    for (int x = 0; x < MAP_WIDTH; x++) {
      if (game->map[y][x] == 'N') {
        game->william.x = x + 0.5;
        game->william.y = y + 0.5;
        game->william.dir_x = 0.0;
        game->william.dir_y = -1.0;
        game->william.plane_x = 0.0;
        game->william.plane_y = tan(game->william.fov / 2.0);
        game->map[y][x] = '0'; // Limpiar la posición del jugador del mapa
        break;
      } else if (game->map[y][x] == 'S') {
        game->william.x = x + 0.5;
        game->william.y = y + 0.5;
        game->william.dir_x = 0.0;
        game->william.dir_y = 1.0;
        game->william.plane_x = 0.0;
        game->william.plane_y = tan(game->william.fov / 2.0);
        game->map[y][x] = '0';
        break;
      } else if (game->map[y][x] == 'E') {
        game->william.x = x + 0.5;
        game->william.y = y + 0.5;
        game->william.dir_x = 1.0;
        game->william.dir_y = 0.0;
        game->william.plane_x = tan(game->william.fov / 2.0);
        game->william.plane_y = 0.0;
        game->map[y][x] = '0';
        break;
      } else if (game->map[y][x] == 'W') {
        game->william.x = x + 0.5;
        game->william.y = y + 0.5;
        game->william.dir_x = -1.0;
        game->william.dir_y = 0.0;
        game->william.plane_x = -tan(game->william.fov / 2.0);
        game->william.plane_y = 0.0;
        game->map[y][x] = '0';
        break;
      }
    }
  }
  return (0);
}
*/

void draw_background(t_game *game) {
    // Definir los colores
    int ground_color = GRASS_GREEN; // Asume que GROUND_GREEN está definido
    int sky_color = SKY_BLUE; // Asume que SKY_BLUE está definido

    // Dibujar la mitad superior (Cielo)
    for (int y = 0; y < WIN_HEIGHT / 2; y++) {
        for (int x = 0; x < WIN_WIDTH; x++) {
            game->img_data[y * WIN_WIDTH + x] = sky_color;
        }
    }

    // Dibujar la mitad inferior (Suelo)
    for (int y = WIN_HEIGHT / 2; y < WIN_HEIGHT; y++) {
        for (int x = 0; x < WIN_WIDTH; x++) {
            game->img_data[y * WIN_WIDTH + x] = ground_color;
        }
    }
}


int init_game1(t_game *game) {
    printf("init_game: Inicio\n");

    // Inicializar MiniLibX
    game->mlx_ptr = mlx_init();
    if (!game->mlx_ptr) {
        fprintf(stderr, "init_game: Error al inicializar MiniLibX\n");
        return (clean_exit(game, "Error: Failed to initialize MiniLibX."));
    }

    // Asignar memoria para las texturas
    game->textures = malloc(5 * sizeof(t_texture));
    if (!game->textures) {
        fprintf(stderr, "init_game: Error al asignar memoria para las texturas\n");
        return (clean_exit(game, "Error: Failed to allocate memory for textures."));
    }

    // Crear la ventana principal
    game->win_ptr = mlx_new_window(game->mlx_ptr, WIN_WIDTH, WIN_HEIGHT, "cub3D - William");
    if (!game->win_ptr) {
        fprintf(stderr, "init_game: Error al crear la ventana\n");
        return (clean_exit(game, "Error: Failed to create window."));
    }

    // Crear la imagen principal (para la vista 3D)
    game->img_ptr = mlx_new_image(game->mlx_ptr, WIN_WIDTH, WIN_HEIGHT);
    game->img_data = (int *)mlx_get_data_addr(
        game->img_ptr, &game->bits_per_pixel, &game->line_length, &game->endian);
    if (!game->img_data) {
        fprintf(stderr, "init_game: Error al obtener la dirección de los datos de la imagen\n");
        return (clean_exit(game, "Error: Failed to get main image data address."));
    }

    printf("init_game: img_ptr = %p, img_data = %p, line_length = %d\n",
           game->img_ptr, game->img_data, game->line_length);
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    
// Crear la imagen combinada para el cielo y el suelo
game->img_ground = malloc(sizeof(struct s_img));
if (!game->img_ground) {
    // Manejar el error: no se pudo asignar memoria
    return 0; // O hacer lo que sea apropiado para tu programa
}
game->img_ground->img_ptr = mlx_new_image(game->mlx_ptr, WIN_WIDTH, WIN_HEIGHT);
if (!game->img_ground->img_ptr) {
    return (clean_exit(game, "Error: Failed to create sky_floor image."));
}

game->img_ground->addr = mlx_get_data_addr(
    game->img_ground->img_ptr, &game->img_ground->bits_per_pixel,
    &game->img_ground->line_length, &game->img_ground->endian);
if (!game->img_ground->addr) {
    return (clean_exit(game, "Error: Failed to get sky_floor image data address."));
}

game->img_ground->width = WIN_WIDTH;
game->img_ground->height = WIN_HEIGHT;
    // Crear la imagen del minimapa

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    game->minimap_img_ptr = mlx_new_image(game->mlx_ptr, MINIMAP_WIDTH, MINIMAP_HEIGHT);
    game->minimap_img_data = (int *)mlx_get_data_addr(
        game->minimap_img_ptr, &game->minimap_bpp, &game->minimap_line_length,
        &game->minimap_endian);
    if (!game->minimap_img_data) {
        fprintf(stderr, "init_game: Error al obtener la dirección de los datos de la imagen del minimapa\n");
        return (clean_exit(game, "Error: Failed to get minimap image data address."));
    }

    // Asignar memoria para el mapa y copiarlo
    game->map = malloc(MAP_HEIGHT * sizeof(char *));
    if (!game->map) {
        fprintf(stderr, "init_game: Error al asignar memoria para el mapa\n");
        return (clean_exit(game, "Error: Failed to allocate memory for map."));
    }
    for (int i = 0; i < MAP_HEIGHT; i++) {
        game->map[i] = malloc((MAP_WIDTH + 1) * sizeof(char));
        if (!game->map[i]) {
            fprintf(stderr, "init_game: Error al asignar memoria para la fila del mapa\n");
            return (clean_exit(game, "Error: Failed to allocate memory for map row."));
        }
        for (int j = 0; j <= MAP_WIDTH; j++) {
            game->map[i][j] = worldMap2[i][j];
        }
    }

    // Inicializar la posición y dirección de William
    game->william.fov = FOV * M_PI / 180.0;
    for (int y = 0; y < MAP_HEIGHT; y++) {
        for (int x = 0; x < MAP_WIDTH; x++) {
            if (game->map[y][x] == 'N') {
                game->william.x = x + 0.5;
                game->william.y = y + 0.5;
                game->william.dir_x = 0.0;
                game->william.dir_y = -1.0;
                game->william.plane_x = 0.0;
                game->william.plane_y = tan(game->william.fov / 2.0);
                game->map[y][x] = '0';
                break;
            } else if (game->map[y][x] == 'S') {
                game->william.x = x + 0.5;
                game->william.y = y + 0.5;
                game->william.dir_x = 0.0;
                game->william.dir_y = 1.0;
                game->william.plane_x = 0.0;
                game->william.plane_y = tan(game->william.fov / 2.0);
                game->map[y][x] = '0';
                break;
            } else if (game->map[y][x] == 'E') {
                game->william.x = x + 0.5;
                game->william.y = y + 0.5;
                game->william.dir_x = 1.0;
                game->william.dir_y = 0.0;
                game->william.plane_x = tan(game->william.fov / 2.0);
                game->william.plane_y = 0.0;
                game->map[y][x] = '0';
                break;
            } else if (game->map[y][x] == 'W') {
                game->william.x = x + 0.5;
                game->william.y = y + 0.5;
                game->william.dir_x = -1.0;
                game->william.dir_y = 0.0;
                game->william.plane_x = -tan(game->william.fov / 2.0);
                game->william.plane_y = 0.0;
                game->map[y][x] = '0';
                break;
            }
        }
    }

    printf("init_game: Fin\n");
    //drawbackground(game);
    return (0);
}

int init_game(t_game *game) {
    printf("init_game: Inicio\n");

    // Inicializar MiniLibX
    game->mlx_ptr = mlx_init();
    if (!game->mlx_ptr) {
        fprintf(stderr, "init_game: Error al inicializar MiniLibX\n");
        return (clean_exit(game, "Error: Failed to initialize MiniLibX."));
    }

    // Asignar memoria para las texturas
    game->textures = malloc(5 * sizeof(t_texture));
    if (!game->textures) {
        fprintf(stderr, "init_game: Error al asignar memoria para las texturas\n");
        return (clean_exit(game, "Error: Failed to allocate memory for textures."));
    }

    // Inicializar las texturas
    if (load_textures(game) != 0) {
        return (clean_exit(game, "Error: Failed to load textures."));
    }

    // Crear la ventana principal
    game->win_ptr = mlx_new_window(game->mlx_ptr, WIN_WIDTH, WIN_HEIGHT, "cub3D - William");
    if (!game->win_ptr) {
        fprintf(stderr, "init_game: Error al crear la ventana\n");
        return (clean_exit(game, "Error: Failed to create window."));
    }

    // Crear la imagen principal (para la vista 3D)
    game->img_ptr = mlx_new_image(game->mlx_ptr, WIN_WIDTH, WIN_HEIGHT);
    game->img_data = (int *)mlx_get_data_addr(
        game->img_ptr, &game->bits_per_pixel, &game->line_length, &game->endian);
    if (!game->img_data) {
        fprintf(stderr, "init_game: Error al obtener la dirección de los datos de la imagen\n");
        return (clean_exit(game, "Error: Failed to get main image data address."));
    }

    // Crear la imagen combinada para el cielo y el suelo
    game->img_ground = malloc(sizeof(struct s_img));
    if (!game->img_ground) {
        return (clean_exit(game, "Error: Failed to allocate memory for ground image."));
    }
    game->img_ground->img_ptr = mlx_new_image(game->mlx_ptr, WIN_WIDTH, WIN_HEIGHT);
    if (!game->img_ground->img_ptr) {
        return (clean_exit(game, "Error: Failed to create sky_floor image."));
    }
    game->img_ground->addr = mlx_get_data_addr(
        game->img_ground->img_ptr, &game->img_ground->bits_per_pixel,
        &game->img_ground->line_length, &game->img_ground->endian);
    if (!game->img_ground->addr) {
        return (clean_exit(game, "Error: Failed to get sky_floor image data address."));
    }

    // Crear la imagen del minimapa
    game->minimap_img_ptr = mlx_new_image(game->mlx_ptr, MINIMAP_WIDTH, MINIMAP_HEIGHT);
    game->minimap_img_data = (int *)mlx_get_data_addr(
        game->minimap_img_ptr, &game->minimap_bpp, &game->minimap_line_length,
        &game->minimap_endian);
    if (!game->minimap_img_data) {
        fprintf(stderr, "init_game: Error al obtener la dirección de los datos de la imagen del minimapa\n");
        return (clean_exit(game, "Error: Failed to get minimap image data address."));
    }

    // Asignar memoria para el mapa y copiarlo
    game->map = malloc(MAP_HEIGHT * sizeof(char *));
    if (!game->map) {
        fprintf(stderr, "init_game: Error al asignar memoria para el mapa\n");
        return (clean_exit(game, "Error: Failed to allocate memory for map."));
    }
    for (int i = 0; i < MAP_HEIGHT; i++) {
        game->map[i] = malloc((MAP_WIDTH + 1) * sizeof(char));
        if (!game->map[i]) {
            return (clean_exit(game, "Error: Failed to allocate memory for map row."));
        }
        for (int j = 0; j <= MAP_WIDTH; j++) {
            game->map[i][j] = worldMap2[i][j];
        }
    }

    // Inicializar la posición y dirección de William
    game->william.fov = FOV * M_PI / 180.0;
    for (int y = 0; y < MAP_HEIGHT; y++) {
        for (int x = 0; x < MAP_WIDTH; x++) {
            if (game->map[y][x] == 'N') {
                game->william.x = x + 0.5;
                game->william.y = y + 0.5;
                game->william.dir_x = 0.0;
                game->william.dir_y = -1.0;
                game->william.plane_x = 0.0;
                game->william.plane_y = tan(game->william.fov / 2.0);
                game->map[y][x] = '0';
                break;
            } else if (game->map[y][x] == 'S') {
                game->william.x = x + 0.5;
                game->william.y = y + 0.5;
                game->william.dir_x = 0.0;
                game->william.dir_y = 1.0;
                game->william.plane_x = 0.0;
                game->william.plane_y = tan(game->william.fov / 2.0);
                game->map[y][x] = '0';
                break;
            } else if (game->map[y][x] == 'E') {
                game->william.x = x + 0.5;
                game->william.y = y + 0.5;
                game->william.dir_x = 1.0;
                game->william.dir_y = 0.0;
                game->william.plane_x = tan(game->william.fov / 2.0);
                game->william.plane_y = 0.0;
                game->map[y][x] = '0';
                break;
            } else if (game->map[y][x] == 'W') {
                game->william.x = x + 0.5;
                game->william.y = y + 0.5;
                game->william.dir_x = -1.0;
                game->william.dir_y = 0.0;
                game->william.plane_x = -tan(game->william.fov / 2.0);
                game->william.plane_y = 0.0;
                game->map[y][x] = '0';
                break;
            }
        }
    }
     if (load_textures(game) != 0) {
        return clean_exit(game, "Error: Failed to load textures.");
    }

    // Cargar imágenes de las manos
    if (load_hands_images(game) != 0) {
        return clean_exit(game, "Error: Failed to load hands images.");
    }
    remove_black_background(game);
    game->hands_x = 400; // Establece la posición X de las manos
    game->hands_y = 536; // Establece la posición Y de las manos
    printf("init_game: Fin\n");
    return (0);
}

int load_textures1(t_game *game) {
    char *texture_paths[5] = {
        "./img/1.xpm",
        "./img/2.xpm",
        "./img/3.xpm",
        "./img/4.xpm",
        "./img/5.xpm"
    };

    for (int i = 0; i < 5; i++) {
        game->textures[i].img_ptr = mlx_xpm_file_to_image(
            game->mlx_ptr, texture_paths[i], // Usamos texture_paths[i] aquí
            &game->textures[i].width, &game->textures[i].height);

        if (!game->textures[i].img_ptr) {
            return (clean_exit(game, "Error: Failed to load texture."));
        }

        game->textures[i].data = (int *)mlx_get_data_addr(
            game->textures[i].img_ptr, &game->textures[i].bits_per_pixel,
            &game->textures[i].line_length, &game->textures[i].endian);

        if (!game->textures[i].data) {
            return (clean_exit(game, "Error: Failed to get texture data address."));
        }
    }

    return (0);
}

int load_hands_images(t_game *game) {
    // Array con las rutas de las imágenes de las manos
    char *hands_paths[2] = {
        "./img/1w.xpm",  // Primera imagen
        "./img/2w.xpm"   // Segunda imagen
    };

    // Iterar sobre el array de rutas de imágenes y cargar cada una
    for (int i = 0; i < 2; i++) {
        // Cargar la imagen de las manos
        game->hands_img_ptr[i] = mlx_xpm_file_to_image(
            game->mlx_ptr, hands_paths[i], 
            &game->hands_width, &game->hands_height);

        if (!game->hands_img_ptr[i]) {
            // Si falla la carga de la imagen, limpiar y salir
            return clean_exit(game, "Error: Failed to load hands image.");
        }

        // Obtener la dirección de los datos de la imagen (pixeles)
        game->hands_data[i] = (int *)mlx_get_data_addr(
            game->hands_img_ptr[i], &game->hands_bits_per_pixel,
            &game->hands_line_length, &game->hands_endian);

        if (!game->hands_data[i]) {
            // Si falla al obtener los datos de la imagen, limpiar y salir
            return clean_exit(game, "Error: Failed to get hands image data address.");
        }

        // Imprimir detalles para depuración
        printf("[HANDS IMAGE %d] Loaded: %s\n", i, hands_paths[i]);
        printf(" - Image Pointer: %p\n", game->hands_img_ptr[i]);
        printf(" - Data Pointer: %p\n", game->hands_data[i]);
        printf(" - Width: %d, Height: %d\n", game->hands_width, game->hands_height);
        printf(" - Bits per pixel: %d, Line Length: %d, Endian: %d\n",
               game->hands_bits_per_pixel, game->hands_line_length, game->hands_endian);
    }

    return 0; // Todo ha ido bien
}

void remove_black_background(t_game *game) {
    int width = game->hands_width;  // Ancho de la imagen de las manos
    int height = game->hands_height;  // Alto de la imagen de las manos

    // Accede a los datos del fotograma actual de las manos
    int *img_data = game->hands_data[game->current_hand_frame];

    // Color negro (0x000000)
    int black_color = 0x000000;

    // Reemplazar los píxeles negros por transparencia (0x00000000)
    for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
            int pixel = img_data[y * width + x];  // Acceso al píxel en la imagen
            if (pixel == black_color) {
                img_data[y * width + x] = 0x00000000;  // Transparente
            }
        }
    }
}




int load_textures(t_game *game) {
    // Array con las rutas de las texturas
    char *texture_paths[5] = {
        "./img/1.xpm",
        "./img/2.xpm",
        "./img/3.xpm",
        "./img/4.xpm",
        "./img/5.xpm"
    };

    // Iteramos sobre el array de rutas de texturas y cargamos cada una
    for (int i = 0; i < 5; i++) {
        // Cargar la imagen de la textura
        game->textures[i].img_ptr = mlx_xpm_file_to_image(
            game->mlx_ptr, texture_paths[i], 
            &game->textures[i].width, &game->textures[i].height);

        if (!game->textures[i].img_ptr) {
            // Si falla la carga de la textura, limpiar y salir
            return clean_exit(game, "Error: Failed to load texture.");
        }

        // Obtener la dirección de los datos de la textura (pixeles)
        game->textures[i].data = (int *)mlx_get_data_addr(
            game->textures[i].img_ptr, &game->textures[i].bits_per_pixel,
            &game->textures[i].line_length, &game->textures[i].endian);

        if (!game->textures[i].data) {
            // Si falla al obtener los datos de la textura, limpiar y salir
            return clean_exit(game, "Error: Failed to get texture data address.");
        }

        // Imprimir detalles para depuración
        printf("[TEXTURE %d] Loaded: %s\n", i, texture_paths[i]);
        printf(" - Image Pointer: %p\n", game->textures[i].img_ptr);
        printf(" - Data Pointer: %p\n", game->textures[i].data);
        printf(" - Width: %d, Height: %d\n", game->textures[i].width, game->textures[i].height);
        printf(" - Bits per pixel: %d, Line Length: %d, Endian: %d\n",
               game->textures[i].bits_per_pixel, game->textures[i].line_length, game->textures[i].endian);
    }

    return 0; // Todo ha ido bien
}


//////////////////////////////borrame al terminar
void display_textures(t_game *game) {
    int x_offset = 0;
    int y_offset = 0;
    //int row = 0;

    for (int i = 0; i < 5; i++) {
        // Dibujar cada textura en la ventana
        mlx_put_image_to_window(
            game->mlx_ptr, game->win_ptr, game->textures[i].img_ptr,
            x_offset, y_offset);

        x_offset += game->textures[i].width + 10; // Espacio entre texturas

        if (i == 2) { // Después de la tercera textura
            x_offset = 0;
            y_offset += game->textures[i].height + 10;
        }
    }
}
//////////////////////////////////////////////////////////////////////////////////////

/*
int render(t_game *game) {
    // Dibujar la escena 3D (aún no implementado)
    // ...

    // Dibujar el minimapa en su imagen
    draw_minimap(game);

    // Calcular el offset para dibujar el minimapa
    int minimap_offset_x = MINIMAP_AREA_OFFSET_X;
    int minimap_offset_y = MINIMAP_AREA_OFFSET_Y;

    // Copiar la imagen del minimapa a la imagen principal
    for (int y = 0; y < MINIMAP_HEIGHT; y++) {
        for (int x = 0; x < MINIMAP_WIDTH; x++) {
            game->img_data[(y + minimap_offset_y) * WIN_WIDTH + (x + minimap_offset_x)] =
                game->minimap_img_data[y * game->minimap_line_length / 4 + x];
        }
    }

    // Actualizar la ventana principal con la imagen principal (que ahora contiene el minimapa)
    mlx_put_image_to_window(game->mlx_ptr, game->win_ptr, game->img_ptr, 0, 0);
    //display_textures(game);
    return (0);
}
*/

/*
int render(t_game *game) {
    // Limpiar la imagen (opcional, pero recomendado)
    memset(game->img_data, 0, game->line_length * WIN_WIDTH);//cambiame por la de la libft

    // Bucle principal del raycasting: iterar sobre cada columna de la pantalla
    for (int x = 0; x < WIN_WIDTH; x++) {
        // Calcular la dirección del rayo
        //double cameraX = 2 * x / (double)WIN_WIDTH - 1; // Coordenada x en la cámara
        //double rayDirX = game->william.dir_x + game->william.plane_x * cameraX;
        //double rayDirY = game->william.dir_y + game->william.plane_y * cameraX;

        // ... (resto de la lógica del raycasting: DDA, distancia, altura, dibujo de la columna) ...

        // Por ahora, solo dibujamos un color de prueba para ver que el bucle funciona
        int color = WHITE;
        for (int y = 0; y < WIN_HEIGHT; y++){
            game->img_data[y * WIN_WIDTH + x] = color;
        }
    }

    // Dibujar el minimapa (opcional, puedes comentarlo temporalmente para simplificar)
    draw_minimap(game);

    // Actualizar la ventana
    mlx_put_image_to_window(game->mlx_ptr, game->win_ptr, game->img_ptr, 0, 0);

    return (0);
}
*/


/* FUNCIONA SIN RAYCASTIN
int render(t_game *game) {
    // 1. Limpieza de la imagen

    // Calcula el tamaño total de la imagen en píxeles (int)
    int total_pixels = WIN_WIDTH * WIN_HEIGHT;

    // Llena la imagen con negro de forma eficiente
    memset(game->img_data, 0, total_pixels * sizeof(int)); // Asume que img_data es int*

    // 2. Raycasting (parte superior de la ventana)

    // Altura máxima para el raycasting (deja espacio para el minimapa)
    int raycast_height = WIN_HEIGHT - WIN_HEIGHT / 4; // Usar 1/4 de la altura para el minimapa

    for (int x = 0; x < WIN_WIDTH; x++) {
        // Calcular la dirección del rayo
        double cameraX = 2.0 * x / WIN_WIDTH - 1.0; // Optimización: Evitar divisiones repetidas
        double rayDirX = game->william.dir_x + game->william.plane_x * cameraX;
        double rayDirY = game->william.dir_y + game->william.plane_y * cameraX;

        // --- Algoritmo DDA ---
        // Coordenadas enteras de la posición del jugador
        int mapX = (int)game->william.x;
        int mapY = (int)game->william.y;

        // Longitud del rayo desde la posición inicial hasta el siguiente lado x o y
        double sideDistX;
        double sideDistY;

        // Longitud del rayo en la dirección x e y
        double deltaDistX = fabs(1.0 / rayDirX);
        double deltaDistY = fabs(1.0 / rayDirY);
        double perpWallDist; // Declared here!

        // Dirección del paso (incremento de la casilla)
        int stepX;
        int stepY;

        int hit = 0; // Si se golpea una pared
        int side;    // Lado de la pared golpeada (E o W / N o S)

        // Calcular la dirección y la distancia inicial
        if (rayDirX < 0) {
            stepX = -1;
            sideDistX = (game->william.x - mapX) * deltaDistX;
        } else {
            stepX = 1;
            sideDistX = (mapX + 1.0 - game->william.x) * deltaDistX;
        }
        if (rayDirY < 0) {
            stepY = -1;
            sideDistY = (game->william.y - mapY) * deltaDistY;
        } else {
            stepY = 1;
            sideDistY = (mapY + 1.0 - game->william.y) * deltaDistY;
        }

        // DDA loop
        while (hit == 0) {
            // Saltar a la siguiente casilla del mapa, ya sea en dirección X o Y
            if (sideDistX < sideDistY) {
                sideDistX += deltaDistX;
                mapX += stepX;
                side = 0; // Golpea pared E o W
            } else {
                sideDistY += deltaDistY;
                mapY += stepY;
                side = 1; // Golpea pared N o S
            }

            // Verificar si el rayo ha golpeado una pared
            if (game->map[mapY][mapX] == '1')
                hit = 1;
        }

        // Calcular la distancia a la pared (perpendicular al plano de la cámara)
        if (side == 0)
            perpWallDist = (mapX - game->william.x + (1 - stepX) / 2.0) / rayDirX;
        else
            perpWallDist = (mapY - game->william.y + (1 - stepY) / 2.0) / rayDirY;

        // ... (resto del código: calcular altura, dibujar columna) ...

        // Por ahora, solo dibujamos un color de prueba para ver que el DDA funciona
        int color = WHITE;
        for (int y = 0; y < raycast_height; y++) {
            game->img_data[y * WIN_WIDTH + x] = color;
        }
    }

    // 3. Fondo para el minimapa (parte inferior izquierda)

    // Calcula las dimensiones del área del minimapa (1/4 del tamaño de la ventana)
    int minimap_area_width = WIN_WIDTH / 4;
    int minimap_area_height = WIN_HEIGHT / 4;

    // Calcula las coordenadas de inicio del fondo del minimapa
    int minimap_offset_x = 10;
    int minimap_offset_y = WIN_HEIGHT - minimap_area_height - 10;

    // Dibuja el fondo negro del minimapa
    for (int y = minimap_offset_y; y < minimap_offset_y + minimap_area_height; y++) {
        for (int x = minimap_offset_x; x < minimap_offset_x + minimap_area_width; x++) {
            game->img_data[y * WIN_WIDTH + x] = BLACK;
        }
    }

    // 4. Dibujar el minimapa

    draw_minimap(game);

    // 5. Escalar y copiar el minimapa a la imagen principal

    // Calcula la escala del minimapa
    double minimap_scale_x = (double)minimap_area_width / (MAP_WIDTH * 8);
    double minimap_scale_y = (double)minimap_area_height / (MAP_HEIGHT * 8);
    double minimap_scale = (minimap_scale_x < minimap_scale_y) ? minimap_scale_x : minimap_scale_y;

    for (int y = 0; y < MINIMAP_HEIGHT; y++) {
        for (int x = 0; x < MINIMAP_WIDTH; x++) {
            // Calcula las coordenadas escaladas
            int scaled_x = (int)(x * minimap_scale);
            int scaled_y = (int)(y * minimap_scale);

            // Copia el píxel si está dentro de los límites del área del minimapa
            if (scaled_x >= 0 && scaled_x < minimap_area_width && scaled_y >= 0 && scaled_y < minimap_area_height) {
                game->img_data[(minimap_offset_y + scaled_y) * WIN_WIDTH + (minimap_offset_x + scaled_x)] =
                    game->minimap_img_data[y * game->minimap_line_length / 4 + x];
            }
        }
    }

    // 6. Actualizar la ventana

    mlx_put_image_to_window(game->mlx_ptr, game->win_ptr, game->img_ptr, 0, 0);

    return (0);
}
*/

// Función auxiliar para dibujar un píxel en la imagen del minimapa
void my_mlx_pixel_put(t_game *game, int x, int y, int color) {
    if (x >= 0 && x < MAP_WIDTH * 8 && y >= 0 && y < MAP_HEIGHT * 8) {
        game->minimap_img_data[y * game->minimap_line_length / 4 + x] = color;
    }
}




#include <limits.h> // Para INT_MAX
/*
int render(t_game *game) {
    // 1. Limpieza de la imagen

    // Calcula el tamaño total de la imagen en píxeles (int)
    int total_pixels = WIN_WIDTH * WIN_HEIGHT;

    // Llena la imagen con negro de forma eficiente
    memset(game->img_data, 0, total_pixels * sizeof(int)); // Asume que img_data es int*

    // 2. Raycasting (parte superior de la ventana)

    // Altura máxima para el raycasting (deja espacio para el minimapa)
    int raycast_height = WIN_HEIGHT - WIN_HEIGHT / 4; // Usar 1/4 de la altura para el minimapa

    for (int x = 0; x < WIN_WIDTH; x++) {
        // Calcular la dirección del rayo
        double cameraX = 2.0 * x / WIN_WIDTH - 1.0; // Optimización: Evitar divisiones repetidas
        double rayDirX = game->william.dir_x + game->william.plane_x * cameraX;
        double rayDirY = game->william.dir_y + game->william.plane_y * cameraX;

        // --- Algoritmo DDA ---
        // Coordenadas enteras de la posición del jugador
        int mapX = (int)game->william.x;
        int mapY = (int)game->william.y;

        // Longitud del rayo desde la posición inicial hasta el siguiente lado x o y
        double sideDistX;
        double sideDistY;

        // Longitud del rayo en la dirección x e y
        double deltaDistX = (rayDirX == 0) ? 1e30 : fabs(1.0 / rayDirX); // Evitar división por cero
        double deltaDistY = (rayDirY == 0) ? 1e30 : fabs(1.0 / rayDirY);
        double perpWallDist; // Distancia perpendicular a la pared

        // Dirección del paso (incremento de la casilla)
        int stepX;
        int stepY;

        int hit = 0; // Si se golpea una pared
        int side;    // Lado de la pared golpeada (E o W / N o S)

        // Calcular la dirección y la distancia inicial
        if (rayDirX < 0) {
            stepX = -1;
            sideDistX = (game->william.x - mapX) * deltaDistX;
        } else {
            stepX = 1;
            sideDistX = (mapX + 1.0 - game->william.x) * deltaDistX;
        }
        if (rayDirY < 0) {
            stepY = -1;
            sideDistY = (game->william.y - mapY) * deltaDistY;
        } else {
            stepY = 1;
            sideDistY = (mapY + 1.0 - game->william.y) * deltaDistY;
        }

        // DDA loop
        while (hit == 0) {
            // Saltar a la siguiente casilla del mapa, ya sea en dirección X o Y
            if (sideDistX < sideDistY) {
                sideDistX += deltaDistX;
                mapX += stepX;
                side = 0; // Golpea pared E o W
            } else {
                sideDistY += deltaDistY;
                mapY += stepY;
                side = 1; // Golpea pared N o S
            }

            // Verificar si el rayo ha golpeado una pared
            if (game->map[mapY][mapX] == '1')
                hit = 1;
        }

        // Calcular la distancia a la pared (perpendicular al plano de la cámara)
        if (side == 0)
            perpWallDist = (mapX - game->william.x + (1 - stepX) / 2.0) / rayDirX;
        else
            perpWallDist = (mapY - game->william.y + (1 - stepY) / 2.0) / rayDirY;

        // --- Calcular la altura de la pared y dibujarla ---

        // Altura de la pared en la pantalla
        int lineHeight = (int)(WIN_HEIGHT / perpWallDist);

        // Calcular el inicio y el fin del dibujo de la pared
        int drawStart = -lineHeight / 2 + WIN_HEIGHT / 2;
        if (drawStart < 0)
            drawStart = 0;
        int drawEnd = lineHeight / 2 + WIN_HEIGHT / 2;
        if (drawEnd >= WIN_HEIGHT)
            drawEnd = WIN_HEIGHT - 1;

        // Dibujar la columna de la pared
        int color = WHITE;
        for (int y = drawStart; y < drawEnd; y++) {
            game->img_data[y * WIN_WIDTH + x] = color;
        }
    }

    // 3. Fondo para el minimapa (parte inferior izquierda)

    // Calcula las dimensiones del área del minimapa (1/4 del tamaño de la ventana)
    int minimap_area_width = WIN_WIDTH / 4;
    int minimap_area_height = WIN_HEIGHT / 4;

    // Calcula las coordenadas de inicio del fondo del minimapa
    int minimap_offset_x = 10;
    int minimap_offset_y = WIN_HEIGHT - minimap_area_height - 10;

    // Dibuja el fondo negro del minimapa
    for (int y = minimap_offset_y; y < minimap_offset_y + minimap_area_height; y++) {
        for (int x = minimap_offset_x; x < minimap_offset_x + minimap_area_width; x++) {
            game->img_data[y * WIN_WIDTH + x] = BLACK;
        }
    }

    // 4. Dibujar el minimapa

    draw_minimap(game);

    // 5. Escalar y copiar el minimapa a la imagen principal

    // Calcula la escala del minimapa
    double minimap_scale_x = (double)minimap_area_width / (MAP_WIDTH * 8);
    double minimap_scale_y = (double)minimap_area_height / (MAP_HEIGHT * 8);
    double minimap_scale = (minimap_scale_x < minimap_scale_y) ? minimap_scale_x : minimap_scale_y;

    for (int y = 0; y < MINIMAP_HEIGHT; y++) {
        for (int x = 0; x < MINIMAP_WIDTH; x++) {
            // Calcula las coordenadas escaladas
            int scaled_x = (int)(x * minimap_scale);
            int scaled_y = (int)(y * minimap_scale);

            // Copia el píxel si está dentro de los límites del área del minimapa
            if (scaled_x >= 0 && scaled_x < minimap_area_width && scaled_y >= 0 && scaled_y < minimap_area_height) {
                game->img_data[(minimap_offset_y + scaled_y) * WIN_WIDTH + (minimap_offset_x + scaled_x)] =
                    game->minimap_img_data[y * game->minimap_line_length / 4 + x];
            }
        }
    }

    // 6. Actualizar la ventana

    mlx_put_image_to_window(game->mlx_ptr, game->win_ptr, game->img_ptr, 0, 0);

    return (0);
}
*/




/*punto de partida
int render(t_game *game) {
    // 1. Limpieza de la imagen

    // Calcula el tamaño total de la imagen en píxeles (int)
    int total_pixels = WIN_WIDTH * WIN_HEIGHT;

    // Llena la imagen con negro de forma eficiente
    memset(game->img_data, 0, total_pixels * sizeof(int)); // Asume que img_data es int*

    // 2. Raycasting (parte superior de la ventana)

    // Altura máxima para el raycasting (deja espacio para el minimapa)
    int raycast_height = WIN_HEIGHT - WIN_HEIGHT / 4; // Usar 1/4 de la altura para el minimapa

    // Ajustar el FOV (Campo de Visión) - Opcional
    double fov_modifier = 0.6; // Valor entre 0 y 1 (menor valor = menor FOV)
    game->william.plane_x = tan(game->william.fov / 2.0) * fov_modifier;
    game->william.plane_y = 0.0; // En 2D, el plano y solo tiene componente x

    for (int x = 0; x < WIN_WIDTH; x++) {
        // Calcular la dirección del rayo
        double cameraX = 2.0 * x / WIN_WIDTH - 1.0; // Optimización: Evitar divisiones repetidas
        double rayDirX = game->william.dir_x + game->william.plane_x * cameraX;
        double rayDirY = game->william.dir_y + game->william.plane_y * cameraX;

        // --- Algoritmo DDA ---
        // Coordenadas enteras de la posición del jugador
        int mapX = (int)game->william.x;
        int mapY = (int)game->william.y;

        // Longitud del rayo desde la posición inicial hasta el siguiente lado x o y
        double sideDistX;
        double sideDistY;

        // Longitud del rayo en la dirección x e y
        double deltaDistX = (rayDirX == 0) ? 1e30 : fabs(1.0 / rayDirX); // Evitar división por cero
        double deltaDistY = (rayDirY == 0) ? 1e30 : fabs(1.0 / rayDirY);
        double perpWallDist; // Distancia perpendicular a la pared

        // Dirección del paso (incremento de la casilla)
        int stepX;
        int stepY;

        int hit = 0; // Si se golpea una pared
        int side;    // Lado de la pared golpeada (E o W / N o S)

        // Calcular la dirección y la distancia inicial
        if (rayDirX < 0) {
            stepX = -1;
            sideDistX = (game->william.x - mapX) * deltaDistX;
        } else {
            stepX = 1;
            sideDistX = (mapX + 1.0 - game->william.x) * deltaDistX;
        }
        if (rayDirY < 0) {
            stepY = -1;
            sideDistY = (game->william.y - mapY) * deltaDistY;
        } else {
            stepY = 1;
            sideDistY = (mapY + 1.0 - game->william.y) * deltaDistY;
        }

        // DDA loop
        while (hit == 0) {
            // Saltar a la siguiente casilla del mapa, ya sea en dirección X o Y
            if (sideDistX < sideDistY) {
                sideDistX += deltaDistX;
                mapX += stepX;
                side = 0; // Golpea pared E o W
            } else {
                sideDistY += deltaDistY;
                mapY += stepY;
                side = 1; // Golpea pared N o S
            }

            // Verificar si el rayo ha golpeado una pared
            if (game->map[mapY][mapX] == '1')
                hit = 1;
        }

        // Calcular la distancia a la pared (perpendicular al plano de la cámara)
        if (side == 0)
            perpWallDist = (mapX - game->william.x + (1 - stepX) / 2.0) / rayDirX;
        else
            perpWallDist = (mapY - game->william.y + (1 - stepY) / 2.0) / rayDirY;

        // --- Calcular la altura de la pared y dibujarla ---

        // Altura de la pared en la pantalla
        int lineHeight = (int)(WIN_HEIGHT / perpWallDist);

        // Calcular el inicio y el fin del dibujo de la pared
        int drawStart = -lineHeight / 2 + WIN_HEIGHT / 2;
        if (drawStart < 0)
            drawStart = 0;
        int drawEnd = lineHeight / 2 + WIN_HEIGHT / 2;
        if (drawEnd >= WIN_HEIGHT)
            drawEnd = WIN_HEIGHT - 1;

        // Imprimir valores de depuración
        printf("DEBUG: x = %d, perpWallDist = %f, lineHeight = %d, drawStart = %d, drawEnd = %d\n",
               x, perpWallDist, lineHeight, drawStart, drawEnd);

        // Dibujar la columna de la pared
        int color = WHITE;
        for (int y = drawStart; y < drawEnd; y++) {
            game->img_data[y * WIN_WIDTH + x] = color;
        }
    }

    // 3. Fondo para el minimapa (parte inferior izquierda)

    // Calcula las dimensiones del área del minimapa (1/4 del tamaño de la ventana)
    int minimap_area_width = WIN_WIDTH / 4;
    int minimap_area_height = WIN_HEIGHT / 4;

    // Calcula las coordenadas de inicio del fondo del minimapa
    int minimap_offset_x = 10;
    int minimap_offset_y = WIN_HEIGHT - minimap_area_height - 10;

    // Dibuja el fondo negro del minimapa
    for (int y = minimap_offset_y; y < minimap_offset_y + minimap_area_height; y++) {
        for (int x = minimap_offset_x; x < minimap_offset_x + minimap_area_width; x++) {
            game->img_data[y * WIN_WIDTH + x] = BLACK;
        }
    }

    // 4. Dibujar el minimapa
    //drawbackground(game);
    draw_minimap(game);
    //draw_sky_floor(game);
    

    // 5. Escalar y copiar el minimapa a la imagen principal

    // Calcula la escala del minimapa
    double minimap_scale_x = (double)minimap_area_width / (MAP_WIDTH * 8);
    double minimap_scale_y = (double)minimap_area_height / (MAP_HEIGHT * 8);
    double minimap_scale = (minimap_scale_x < minimap_scale_y) ? minimap_scale_x : minimap_scale_y;

    for (int y = 0; y < MINIMAP_HEIGHT; y++) {
        for (int x = 0; x < MINIMAP_WIDTH; x++) {
            // Calcula las coordenadas escaladas
            int scaled_x = (int)(x * minimap_scale);
            int scaled_y = (int)(y * minimap_scale);

            // Copia el píxel si está dentro de los límites del área del minimapa
            if (scaled_x >= 0 && scaled_x < minimap_area_width && scaled_y >= 0 && scaled_y < minimap_area_height) {
                game->img_data[(minimap_offset_y + scaled_y) * WIN_WIDTH + (minimap_offset_x + scaled_x)] =
                    game->minimap_img_data[y * game->minimap_line_length / 4 + x];
            }
        }
    }

    // 6. Actualizar la ventana
    
    mlx_put_image_to_window(game->mlx_ptr, game->win_ptr, game->img_ptr, 0, 0);
    
    return (0);
}
*/

int render(t_game *game) {
    // 1. Limpiar la imagen principal
    int total_pixels = WIN_WIDTH * WIN_HEIGHT;
    memset(game->img_data, 0, total_pixels * sizeof(int));

    draw_background(game);

    // 2. Raycasting
    int raycast_height = WIN_HEIGHT - WIN_HEIGHT / 4;
    double fov_modifier = 0.6;
    game->william.plane_x = tan(game->william.fov / 2.0) * fov_modifier;
    game->william.plane_y = 0.0;

    // Buffer para almacenar los valores de depuración que se imprimirán solo al final
    char debug_output[1000] = "";

    for (int x = 0; x < WIN_WIDTH; x++) {
        double cameraX = 2.0 * x / WIN_WIDTH - 1.0;
        double rayDirX = game->william.dir_x + game->william.plane_x * cameraX;
        double rayDirY = game->william.dir_y + game->william.plane_y * cameraX;

        int mapX = (int)game->william.x;
        int mapY = (int)game->william.y;

        double deltaDistX = (rayDirX == 0) ? 1e30 : fabs(1.0 / rayDirX);
        double deltaDistY = (rayDirY == 0) ? 1e30 : fabs(1.0 / rayDirY);
        double sideDistX, sideDistY;

        int stepX = (rayDirX < 0) ? -1 : 1;
        sideDistX = (rayDirX < 0) ?
            (game->william.x - mapX) * deltaDistX :
            (mapX + 1.0 - game->william.x) * deltaDistX;

        int stepY = (rayDirY < 0) ? -1 : 1;
        sideDistY = (rayDirY < 0) ?
            (game->william.y - mapY) * deltaDistY :
            (mapY + 1.0 - game->william.y) * deltaDistY;

        int hit = 0, side;
        while (hit == 0) {
            if (sideDistX < sideDistY) {
                sideDistX += deltaDistX;
                mapX += stepX;
                side = 0;
            } else {
                sideDistY += deltaDistY;
                mapY += stepY;
                side = 1;
            }
            if (game->map[mapY][mapX] == '1') hit = 1;
        }

        double perpWallDist = (side == 0) ?
            (mapX - game->william.x + (1 - stepX) / 2.0) / rayDirX :
            (mapY - game->william.y + (1 - stepY) / 2.0) / rayDirY;

        int lineHeight = (int)(WIN_HEIGHT / perpWallDist);
        int drawStart = -lineHeight / 2 + WIN_HEIGHT / 2;
        if (drawStart < 0) drawStart = 0;
        int drawEnd = lineHeight / 2 + WIN_HEIGHT / 2;
        if (drawEnd >= WIN_HEIGHT) drawEnd = WIN_HEIGHT - 1;

        // === TEXTURA ===
        double wallX;
        if (side == 0)
            wallX = game->william.y + perpWallDist * rayDirY;
        else
            wallX = game->william.x + perpWallDist * rayDirX;
        wallX -= floor(wallX);

        int texX = (int)(wallX * (double)TEX_WIDTH);
        if ((side == 0 && rayDirX > 0) || (side == 1 && rayDirY < 0))
            texX = TEX_WIDTH - texX - 1;

        // Determinar textura según dirección
        int tex_id = 0;
        if (side == 0)
            tex_id = (rayDirX > 0) ? 0 : 1; // E o W
        else
            tex_id = (rayDirY > 0) ? 2 : 3; // S o N

        t_texture *tex = &game->textures[tex_id];

        for (int y = drawStart; y < drawEnd; y++) {
            int d = y * 256 - WIN_HEIGHT * 128 + lineHeight * 128;
            int texY = ((d * TEX_HEIGHT) / lineHeight) / 256;
            if (texY >= TEX_HEIGHT) texY = TEX_HEIGHT - 1;

            int color = tex->data[texY * (tex->line_length / 4) + texX];
            game->img_data[y * WIN_WIDTH + x] = color;
        }

        // Almacenar los valores de depuración de la dirección y giro del jugador
        
    }

    // Imprimir la información de depuración al final
    
    printf("PLANE_X: %.6f | PLANE_Y: %.6f\n", game->william.plane_x, game->william.plane_y);
    printf("DIR_X: %.6f | DIR_Y: %.6f\n", game->william.dir_x, game->william.dir_y);

    // 3. Fondo del minimapa
    int minimap_area_width = WIN_WIDTH / 4;
    int minimap_area_height = WIN_HEIGHT / 4;
    int minimap_offset_x = 10;
    int minimap_offset_y = WIN_HEIGHT - minimap_area_height - 10;

    for (int y = minimap_offset_y; y < minimap_offset_y + minimap_area_height; y++) {
        for (int x = minimap_offset_x; x < minimap_offset_x + minimap_area_width; x++) {
            game->img_data[y * WIN_WIDTH + x] = BLACK;
        }
    }

    // 4. Dibujar el minimapa
    draw_minimap(game);

    // 5. Escalar minimapa
    double minimap_scale_x = (double)minimap_area_width / (MAP_WIDTH * 8);
    double minimap_scale_y = (double)minimap_area_height / (MAP_HEIGHT * 8);
    double minimap_scale = (minimap_scale_x < minimap_scale_y) ? minimap_scale_x : minimap_scale_y;

    for (int y = 0; y < MINIMAP_HEIGHT; y++) {
        for (int x = 0; x < MINIMAP_WIDTH; x++) {
            int scaled_x = (int)(x * minimap_scale);
            int scaled_y = (int)(y * minimap_scale);

            if (scaled_x >= 0 && scaled_x < minimap_area_width && scaled_y >= 0 && scaled_y < minimap_area_height) {
                game->img_data[(minimap_offset_y + scaled_y) * WIN_WIDTH + (minimap_offset_x + scaled_x)] =
                    game->minimap_img_data[y * game->minimap_line_length / 4 + x];
            }
        }
    }

    // 6. Mostrar imagen final
    mlx_put_image_to_window(game->mlx_ptr, game->win_ptr, game->img_ptr, 0, 0);

    return 0;
}


void draw_sky_floor(t_game *game) {
    int x, y;
    int color;
    //int *buffer = (int *)game->sky_floor_img_data;  // Original

    t_img *img = (t_img *)game->img_ground; // Asumiendo que img_data es un t_img*

    // Dibuja el fondo (cielo y césped)
    for (y = 0; y < WIN_HEIGHT; y++) {
        color = (y < WIN_HEIGHT / 2) ? SKY_BLUE : GRASS_GREEN;  // Cielo o césped
        for (x = 0; x < WIN_WIDTH; x++) {
            img->addr[y * WIN_WIDTH + x] = color;  // Asignamos el color al píxel
        }
    }

    // Colocamos la imagen del fondo en la ventana
    mlx_put_image_to_window(game->mlx_ptr, game->win_ptr, game->img_ground, 0, 0);
}

void drawbackground(t_game *data) {
    // Pintar todo el fondo con un solo color (cielo azul o verde césped)
    for (int y = 0; y < WIN_HEIGHT; y++) {
        for (int x = 0; x < WIN_WIDTH; x++) {
            if (y < WIN_HEIGHT / 2) {
                mlx_pixel_put(data->mlx_ptr, data->win_ptr, x, y, SKY_BLUE);  // Cielo azul
            } else {
                mlx_pixel_put(data->mlx_ptr, data->win_ptr, x, y, GRASS_GREEN);  // Suelo verde
            }
        }
    }
}

//#include "cub3D.h"
#include <limits.h> // Para INT_MAX
#include <stdio.h>  // Para printf (depuración)
#include <math.h>   // Para cos, sin
/*
int render(t_game *game) {
    // 1. Limpieza de la imagen

    // Calcula el tamaño total de la imagen en píxeles (int)
    int total_pixels = WIN_WIDTH * WIN_HEIGHT;

    // Llena la imagen con negro de forma eficiente
    //memset(game->img_data, 0, total_pixels * sizeof(int)); // Asume que img_data es int*
    
    // 2. Raycasting (parte superior de la ventana)

    // Altura máxima para el raycasting (deja espacio para el minimapa)
    int raycast_height = WIN_HEIGHT - WIN_HEIGHT / 4; // Usar 1/4 de la altura para el minimapa

    // Ajustar el FOV (Campo de Visión) - Opcional
    double fov_modifier = 0.6; // Valor entre 0 y 1 (menor valor = menor FOV)
    game->william.plane_x = tan(game->william.fov / 2.0) * fov_modifier;
    game->william.plane_y = 0.0; // En 2D, el plano y solo tiene componente x

    for (int x = 0; x < WIN_WIDTH; x++) {
        // Calcular la dirección del rayo
        double cameraX = 2.0 * x / WIN_WIDTH - 1.0; // Optimización: Evitar divisiones repetidas
        double rayDirX = game->william.dir_x + game->william.plane_x * cameraX;
        double rayDirY = game->william.dir_y + game->william.plane_y * cameraX;

        // --- Algoritmo DDA ---
        // Coordenadas enteras de la posición del jugador
        int mapX = (int)game->william.x;
        int mapY = (int)game->william.y;

        // Longitud del rayo desde la posición inicial hasta el siguiente lado x o y
        double sideDistX;
        double sideDistY;

        // Longitud del rayo en la dirección x e y
        double deltaDistX = (rayDirX == 0) ? 1e30 : fabs(1.0 / rayDirX); // Evitar división por cero
        double deltaDistY = (rayDirY == 0) ? 1e30 : fabs(1.0 / rayDirY);
        double perpWallDist; // Distancia perpendicular a la pared

        // Dirección del paso (incremento de la casilla)
        int stepX;
        int stepY;

        int hit = 0; // Si se golpea una pared
        int side;    // Lado de la pared golpeada (E o W / N o S)

        // Calcular la dirección y la distancia inicial
        if (rayDirX < 0) {
            stepX = -1;
            sideDistX = (game->william.x - mapX) * deltaDistX;
        } else {
            stepX = 1;
            sideDistX = (mapX + 1.0 - game->william.x) * deltaDistX;
        }
        if (rayDirY < 0) {
            stepY = -1;
            sideDistY = (game->william.y - mapY) * deltaDistY;
        } else {
            stepY = 1;
            sideDistY = (mapY + 1.0 - game->william.y) * deltaDistY;
        }

        // DDA loop
        while (hit == 0) {
            // Saltar a la siguiente casilla del mapa, ya sea en dirección X o Y
            if (sideDistX < sideDistY) {
                sideDistX += deltaDistX;
                mapX += stepX;
                side = 0; // Golpea pared E o W
            } else {
                sideDistY += deltaDistY;
                mapY += stepY;
                side = 1; // Golpea pared N o S
            }

            // Verificar si el rayo ha golpeado una pared
            if (game->map[mapY][mapX] == '1')
                hit = 1;
        }

        // Calcular la distancia a la pared (perpendicular al plano de la cámara)
        if (side == 0)
            perpWallDist = (mapX - game->william.x + (1 - stepX) / 2.0) / rayDirX;
        else
            perpWallDist = (mapY - game->william.y + (1 - stepY) / 2.0) / rayDirY;

        // --- Calcular la altura de la pared y dibujarla ---

        // Altura de la pared en la pantalla
        int lineHeight = (int)(WIN_HEIGHT / perpWallDist);

        // Calcular el inicio y el fin del dibujo de la pared
        int drawStart = -lineHeight / 2 + WIN_HEIGHT / 2;
        if (drawStart < 0)
            drawStart = 0;
        int drawEnd = lineHeight / 2 + WIN_HEIGHT / 2;
        if (drawEnd >= WIN_HEIGHT)
            drawEnd = WIN_HEIGHT - 1;

        // Imprimir valores de depuración
        printf("DEBUG: x = %d, perpWallDist = %f, lineHeight = %d, drawStart = %d, drawEnd = %d\n",
               x, perpWallDist, lineHeight, drawStart, drawEnd);

        // Dibujar la columna de la pared
        int color = WHITE;
        for (int y = drawStart; y < drawEnd; y++) {
            game->img_data[y * WIN_WIDTH + x] = color;
        }
    }

    // 3. Fondo para el minimapa (parte inferior izquierda)

    // Calcula las dimensiones del área del minimapa (1/4 del tamaño de la ventana)
    int minimap_area_width = WIN_WIDTH / 4;
    int minimap_area_height = WIN_HEIGHT / 4;

    // Calcula las coordenadas de inicio del fondo del minimapa
    int minimap_offset_x = 10;
    int minimap_offset_y = WIN_HEIGHT - minimap_area_height - 10;
    
    // Dibuja el fondo negro del minimapa
    for (int y = minimap_offset_y; y < minimap_offset_y + minimap_area_height; y++) {
        for (int x = minimap_offset_x; x < minimap_offset_x + minimap_area_width; x++) {
            game->img_data[y * WIN_WIDTH + x] = BLACK;
        }
    }

    // 4. Dibujar el minimapa
    
    draw_minimap(game);
    //draw_sky_floor(game);
    

    // 5. Escalar y copiar el minimapa a la imagen principal

    // Calcula la escala del minimapa
    double minimap_scale_x = (double)minimap_area_width / (MAP_WIDTH * 8);
    double minimap_scale_y = (double)minimap_area_height / (MAP_HEIGHT * 8);
    double minimap_scale = (minimap_scale_x < minimap_scale_y) ? minimap_scale_x : minimap_scale_y;

    for (int y = 0; y < MINIMAP_HEIGHT; y++) {
        for (int x = 0; x < MINIMAP_WIDTH; x++) {
            // Calcula las coordenadas escaladas
            int scaled_x = (int)(x * minimap_scale);
            int scaled_y = (int)(y * minimap_scale);

            // Copia el píxel si está dentro de los límites del área del minimapa
            if (scaled_x >= 0 && scaled_x < minimap_area_width && scaled_y >= 0 && scaled_y < minimap_area_height) {
                game->img_data[(minimap_offset_y + scaled_y) * WIN_WIDTH + (minimap_offset_x + scaled_x)] =
                    game->minimap_img_data[y * game->minimap_line_length / 4 + x];
            }
        }
    }

    // 6. Actualizar la ventana
    
    mlx_put_image_to_window(game->mlx_ptr, game->win_ptr, game->img_ptr, 0, 0);
    
    return (0);
}

*/
// Función para dibujar el minimapa
void draw_minimap(t_game *game) {
    int x, y, map_x, map_y;

    for (y = 0; y < MAP_HEIGHT; y++) {
        for (x = 0; x < MAP_WIDTH; x++) {
            map_x = x * 8;   // Fixed scale: 8
            map_y = y * 8;   // Fixed scale: 8
            int color = BLACK; // Color por defecto (espacio vacío)
            if (game->map[y][x] == '1')
                color = WHITE; // Paredes
            else if (game->map[y][x] == '0')
                color = BLACK; // Espacio vacío
            else if (game->map[y][x] == 'N' || game->map[y][x] == 'S' ||
                     game->map[y][x] == 'E' || game->map[y][x] == 'W')
                color = BLACK; // No dibujar la celda del mapa aquí
            for (int i = 0; i < 8; i++) {   // Fixed scale: 8
                for (int j = 0; j < 8; j++) {  // Fixed scale: 8
                    my_mlx_pixel_put(game, map_x + i, map_y + j, color);
                }
            }
        }
    }

    // Dibujar a William como un círculo rojo
    int player_x = (int)(game->william.x * 8);  // Fixed scale: 8
    int player_y = (int)(game->william.y * 8);  // Fixed scale: 8
    int circle_radius = 3; // Radio del círculo de William

    for (int i = -circle_radius; i <= circle_radius; i++) {
        for (int j = -circle_radius; j <= circle_radius; j++) {
            if (i * i + j * j <= circle_radius * circle_radius) {
                my_mlx_pixel_put(game, player_x + i, player_y + j, RED);
            }
        }
    }

    // Dibujar la dirección de William como una línea
    

    // Dibujar el cono de visión (aproximado con dos líneas)
    double fov_half = game->william.fov / 2.0;
    double dir_length = 8; // Longitud de las líneas del cono (Fixed scale: 8)

    // Línea izquierda del cono
    double left_dir_x =
        game->william.dir_x * cos(fov_half) - game->william.dir_y * sin(fov_half);
    double left_dir_y =
        game->william.dir_x * sin(fov_half) + game->william.dir_y * cos(fov_half);
    for (int i = 0; i < dir_length; i++) {
        my_mlx_pixel_put(game, player_x + (int)(left_dir_x * i),
                         player_y + (int)(left_dir_y * i), YELLOW);
    }

    // Línea derecha del cono
    double right_dir_x =
        game->william.dir_x * cos(fov_half) + game->william.dir_y * sin(fov_half);
    double right_dir_y =
        game->william.dir_y * -sin(fov_half) + game->william.dir_y * cos(fov_half);
    for (int i = 0; i < dir_length; i++) {
        my_mlx_pixel_put(game, player_x + (int)(right_dir_x * i),
                         player_y + (int)(right_dir_y * i), YELLOW);
    }
}



int clean_exit(t_game *game, char *msg) {
    // Liberar recursos de MiniLibX
    if (game->img_ptr)
        mlx_destroy_image(game->mlx_ptr, game->img_ptr);
    if (game->minimap_img_ptr)
        mlx_destroy_image(game->mlx_ptr, game->minimap_img_ptr);
    if (game->win_ptr)
        mlx_destroy_window(game->mlx_ptr, game->win_ptr);
    if (game->mlx_ptr)
        mlx_destroy_display(game->mlx_ptr);
    free(game->mlx_ptr);

    // Liberar la memoria del mapa
    if (game->map) {
        for (int i = 0; i < MAP_HEIGHT; i++) {
            if (game->map[i])
                free(game->map[i]);
        }
        free(game->map);
    }

    fprintf(stderr, "%s\n", msg);
    return (1);
}



void alguna_funcion() {
    if (BONUS)
        // Código que solo se compila cuando BONUS es 1 (bonus activados)
        printf("Funcionalidad bonus activada!\n");
        // ... lógica específica de los bonus ...
    else
        // Código que se compila cuando BONUS es 0 (bonus desactivados)
        printf("Funcionalidad estándar.\n");
        // ... lógica estándar ...
    
}

bool is_valid_move(t_game *game, double new_x, double new_y) {
    int map_x = (int)new_x;
    int map_y = (int)new_y;

    // Verificar si las coordenadas están fuera del mapa
    if (map_x < 0 || map_x >= MAP_WIDTH || map_y < 0 || map_y >= MAP_HEIGHT) {
        return false; // Movimiento fuera del mapa: ¡Inválido!
    }

    // Verificar si la celda es una pared
    if (game->map[map_y][map_x] == '1') {
    if (BONUS)
        // ***Parte Bonus:***
        // En la parte bonus, ¡CUALQUIER pared impide el movimiento!
        return false; // Colisión con pared: ¡Inválido!
    else{
        // ***Parte Obligatoria:***
        // En la parte obligatoria, solo las paredes del borde impiden el movimiento.
        if (map_x == 0 || map_x == MAP_WIDTH - 1 || map_y == 0 ||
            map_y == MAP_HEIGHT - 1) {
            return false; // Pared del borde: ¡Inválido!
        } else {
            return true; // Pared interna: ¡Válido!
        }
    }
    }

    return true; // Movimiento válido
}

void update_hands_animation(t_game *game) {
    // Incrementar el temporizador de la animación
    game->hand_animation_timer++;

    // Si hemos pasado el tiempo para cambiar el fotograma (por ejemplo, 10 frames)
    if (game->hand_animation_timer >= 10) {
        // Cambiar al siguiente fotograma (alternar entre 0 y 1)
        game->current_hand_frame = (game->current_hand_frame + 1) % 2;

        // Reiniciar el temporizador
        game->hand_animation_timer = 0;
    }
}

void render_hands(t_game *game) {
    // Usar la imagen actual para mostrar las manos
    mlx_put_image_to_window(game->mlx_ptr, game->win_ptr,
                            game->hands_img_ptr[game->current_hand_frame], 
                            game->hands_x, game->hands_y);
}

void update_player(t_game *game, int keycode) {
    double move_step = MOVE_SPEED;   // Distancia a mover en cada paso
    double rotate_speed = ROTATE_SPEED; // Ángulo de rotación en cada paso
    double new_x, new_y;
    double old_dir_x, old_plane_x;

    // Movimiento
    if (keycode == K_W) {
        new_x = game->william.x + game->william.dir_x * move_step;
        new_y = game->william.y + game->william.dir_y * move_step;
        if (is_valid_move(game, new_x, new_y)) {
            game->william.x = new_x;
            game->william.y = new_y;
        }
    } else if (keycode == K_S) {
        new_x = game->william.x - game->william.dir_x * move_step;
        new_y = game->william.y - game->william.dir_y * move_step;
        if (is_valid_move(game, new_x, new_y)) {
            game->william.x = new_x;
            game->william.y = new_y;
        }
    } else if (keycode == K_A) {
        new_x = game->william.x + game->william.dir_y * move_step;
        new_y = game->william.y - game->william.dir_x * move_step;
        if (is_valid_move(game, new_x, new_y)) {
            game->william.x = new_x;
            game->william.y = new_y;
        }
    } else if (keycode == K_D) {
        new_x = game->william.x - game->william.dir_y * move_step;
        new_y = game->william.y + game->william.dir_x * move_step;
        if (is_valid_move(game, new_x, new_y)) {
            game->william.x = new_x;
            game->william.y = new_y;
        }
    }

    // Rotación
    if (keycode == K_LEFT) {
        // Guardar la dirección y el plano antiguos
        old_dir_x = game->william.dir_x;
        old_plane_x = game->william.plane_x;

        // Aplicar la rotación
        game->william.dir_x = game->william.dir_x * cos(rotate_speed) - game->william.dir_y * sin(rotate_speed);
        game->william.dir_y = old_dir_x * sin(rotate_speed) + game->william.dir_y * cos(rotate_speed);
        game->william.plane_x = game->william.plane_x * cos(rotate_speed) - game->william.plane_y * sin(rotate_speed);
        game->william.plane_y = old_plane_x * sin(rotate_speed) + game->william.plane_y * cos(rotate_speed);
    } else if (keycode == K_RIGHT) {
        // Guardar la dirección y el plano antiguos
        old_dir_x = game->william.dir_x;
        old_plane_x = game->william.plane_x;

        // Aplicar la rotación (en dirección opuesta)
        game->william.dir_x = game->william.dir_x * cos(-rotate_speed) - game->william.dir_y * sin(-rotate_speed);
        game->william.dir_y = old_dir_x * sin(-rotate_speed) + game->william.dir_y * cos(-rotate_speed);
        game->william.plane_x = game->william.plane_x * cos(-rotate_speed) - game->william.plane_y * sin(-rotate_speed);
        //game->william.plane_y = old_plane_x * sin(-rotate_speed) + game->william.dir_y * cos(-rotate_speed);
        game->william.plane_y = old_plane_x * sin(-rotate_speed) + game->william.plane_y * cos(-rotate_speed);

    }
}
void print_player_position(t_game *game) {
    printf("Player position: x = %f, y = %f\n", game->william.x, game->william.y);
}

int handle_input(int keycode, t_game *game) {
    if (keycode == K_ESC) {
        //clean_exit(game, "Exiting game.");
        exit (0);
    }

    update_player(game, keycode);
    render(game);
    //update_hands_animation(game);
    //render_hands(game);
    //draw_background(game);
    print_player_position(game);
    return (0);
}




int game_loop(t_game *game) {
    printf("Entrando en el bucle de eventos...\n"); // AÑADE ESTO
    // Eventos
    //mlx_hook(game->win_ptr, 2, 0, handle_input, game); // 2 es el evento de "tecla presionada"
    mlx_hook(game->win_ptr, KeyPress, KeyPressMask, handle_input, game);
    mlx_hook(game->win_ptr, 17, 0, clean_exit, game); // 17 es el evento de "cerrar ventana"
    mlx_loop(game->mlx_ptr);
    printf("Saliendo del bucle de eventos...\n"); // AÑADE ESTO
    return (0);
}

void test_raycasting(t_game *game) {
    // Inicializar algunos valores de prueba (puedes ajustarlos)
    game->william.x = 3.0;
    game->william.y = 3.0;
    game->william.dir_x = 1.0;
    game->william.dir_y = 0.0;
    game->william.plane_x = 0.0;
    game->william.plane_y = 0.66; // Ajusta este valor para cambiar el FOV

    render(game);
}


int main() {
    t_game game;
    printf("main: Inicio\n");

    // Inicialización
    game.mlx_ptr = NULL;
    game.win_ptr = NULL;
    game.img_ptr = NULL;
    game.img_data = NULL;
    game.minimap_img_ptr = NULL;
    game.minimap_img_data = NULL;
    game.map = NULL;
    game.textures = NULL;
    //game.texture_win_ptr = NULL; // Si la usas

    if (init_game(&game)) {
        printf("main: Error en init_game\n");
        return (1);
    }

    printf("main: Llamando a render\n");
    render(&game);
    printf("main: Llamando a game_loop\n");
    game_loop(&game);

    printf("main: Fin\n");
    return (0);
}
/*
int main() {
    t_game game;
    // ... (inicialización) ...

    if (init_game(&game))
        return (1);

    load_textures(&game); // Cargar texturas ANTES de renderizar
    test_raycasting(&game); // Llamar a la función de prueba
    render(&game);       // Dibujar la escena inicial
    game_loop(&game);   // Iniciar el bucle de eventos

    return (0);
}
*/


/*
int main() {
    t_game game;
    // ... (inicialización) ...
    printf("Llamando a alguna_funcion\n"); // AÑADE ESTO
    alguna_funcion();
    
    if (init_game(&game)) {
        printf("Error en init_game\n"); // AÑADE ESTO
        return (1);
    }
    load_textures(&game);
    printf("Llamando a render\n"); // AÑADE ESTO
    render(&game);
    printf("Llamando a game_loop\n"); // AÑADE ESTO
    
    game_loop(&game);
    //display_textures(&game);

    printf("Saliendo de main\n"); // AÑADE ESTO
    return (0);
}

*/
